const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");

const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.join(__dirname, "uploads");
const PUBLIC_DIR = path.join(__dirname, "public");
const MAX_FILE_SIZE = 100 * 1024 * 1024 * 1024; // 100 GB
const MAX_FILE_LABEL = "100 GB";
const LINK_EXPIRY_DAYS = 7;

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const links = new Map();

function loadLinks() {
  const metaPath = path.join(UPLOAD_DIR, "links.json");
  if (!fs.existsSync(metaPath)) return;
  try {
    const data = JSON.parse(fs.readFileSync(metaPath, "utf8"));
    for (const [id, info] of Object.entries(data)) {
      links.set(id, info);
    }
  } catch {
    /* ignore */
  }
}

function saveLinks() {
  const metaPath = path.join(UPLOAD_DIR, "links.json");
  fs.writeFileSync(metaPath, JSON.stringify(Object.fromEntries(links), null, 2));
}

function cleanupExpired() {
  const now = Date.now();
  let changed = false;
  for (const [id, info] of links) {
    if (info.expiresAt < now) {
      const filePath = path.join(UPLOAD_DIR, info.storedName);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      links.delete(id);
      changed = true;
    }
  }
  if (changed) saveLinks();
}

function streamToFile(req, destPath, maxSize) {
  return new Promise((resolve, reject) => {
    const contentLength = parseInt(req.headers["content-length"], 10);
    if (!Number.isNaN(contentLength) && contentLength > maxSize) {
      return reject(new Error("FILE_TOO_LARGE"));
    }

    const ws = fs.createWriteStream(destPath);
    let size = 0;
    let rejected = false;

    const fail = (err) => {
      if (rejected) return;
      rejected = true;
      req.unpipe(ws);
      ws.destroy();
      fs.unlink(destPath, () => {});
      reject(err);
    };

    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > maxSize) fail(new Error("FILE_TOO_LARGE"));
    });

    req.pipe(ws);

    ws.on("finish", () => {
      if (!rejected) resolve(size);
    });
    ws.on("error", fail);
    req.on("error", fail);
  });
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Content-Length": Buffer.byteLength(body),
  });
  res.end(body);
}

function serveStatic(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mime = MIME[ext] || "application/octet-stream";
  const data = fs.readFileSync(filePath);
  res.writeHead(200, { "Content-Type": mime });
  res.end(data);
}

loadLinks();
setInterval(cleanupExpired, 60 * 60 * 1000);

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  try {
    if (req.method === "POST" && pathname === "/api/upload") {
      const rawName = req.headers["x-filename"] || "archive.zip";
      const originalName = decodeURIComponent(rawName);
      const ext = path.extname(originalName).toLowerCase();
      if (ext !== ".zip") {
        return sendJson(res, 400, { error: "Only .zip files are allowed" });
      }

      const id = crypto.randomUUID();
      const storedName = `${id}.zip`;
      const filePath = path.join(UPLOAD_DIR, storedName);
      const fileSize = await streamToFile(req, filePath, MAX_FILE_SIZE);

      const expiresAt = Date.now() + LINK_EXPIRY_DAYS * 24 * 60 * 60 * 1000;
      links.set(id, {
        storedName,
        originalName,
        size: fileSize,
        createdAt: Date.now(),
        expiresAt,
      });
      saveLinks();

      const baseUrl = `http://${req.headers.host}`;
      return sendJson(res, 200, {
        id,
        url: `${baseUrl}/d/${id}`,
        originalName,
        size: fileSize,
        expiresAt,
        expiresInDays: LINK_EXPIRY_DAYS,
      });
    }

    if (req.method === "GET" && pathname.startsWith("/d/")) {
      const id = pathname.slice(3);
      const info = links.get(id);
      if (!info) {
        res.writeHead(404, { "Content-Type": "text/plain" });
        return res.end("Link not found or expired");
      }
      if (info.expiresAt < Date.now()) {
        links.delete(id);
        saveLinks();
        const filePath = path.join(UPLOAD_DIR, info.storedName);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        res.writeHead(410, { "Content-Type": "text/plain" });
        return res.end("This link has expired");
      }

      const filePath = path.join(UPLOAD_DIR, info.storedName);
      if (!fs.existsSync(filePath)) {
        links.delete(id);
        saveLinks();
        res.writeHead(404, { "Content-Type": "text/plain" });
        return res.end("File not found");
      }

      const stat = fs.statSync(filePath);
      res.writeHead(200, {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="${info.originalName.replace(/"/g, "")}"`,
        "Content-Length": stat.size,
      });
      fs.createReadStream(filePath).pipe(res);
      return;
    }

    if (req.method === "GET") {
      let file = pathname === "/" ? "/index.html" : pathname;
      const safePath = path.normalize(file).replace(/^(\.\.[/\\])+/, "");
      const filePath = path.join(PUBLIC_DIR, safePath);
      if (filePath.startsWith(PUBLIC_DIR) && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        return serveStatic(res, filePath);
      }
    }

    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Not found");
  } catch (err) {
    if (err.message === "FILE_TOO_LARGE") {
      return sendJson(res, 400, { error: `File too large (max ${MAX_FILE_LABEL})` });
    }
    sendJson(res, 500, { error: "Server error" });
  }
});

// Allow very long uploads (100 GB can take hours)
server.requestTimeout = 0;
server.headersTimeout = 0;
server.timeout = 0;

server.listen(PORT, () => {
  console.log(`ZipToURL running at http://localhost:${PORT}`);
  console.log(`Max ZIP size: ${MAX_FILE_LABEL}`);
});
